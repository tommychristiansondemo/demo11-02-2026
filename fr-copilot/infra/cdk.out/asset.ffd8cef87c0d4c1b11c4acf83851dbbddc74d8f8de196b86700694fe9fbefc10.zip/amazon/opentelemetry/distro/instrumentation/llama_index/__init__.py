# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0
import logging
from typing import Any, Collection

from amazon.opentelemetry.distro.version import __version__
from opentelemetry import trace
from opentelemetry.instrumentation.instrumentor import BaseInstrumentor  # type: ignore

logger = logging.getLogger(__name__)


class LlamaIndexInstrumentor(BaseInstrumentor):  # type: ignore
    """
    An instrumentor for LlamaIndex
    """

    _span_handler = None
    _event_handler = None

    def instrumentation_dependencies(self) -> Collection[str]:  # pylint: disable=no-self-use
        return (
            "llama-index-core >= 0.13.0, < 1",
            "llama-index-workflows >= 1.0.1, != 2.24.0, < 3",
        )

    def _instrument(self, **kwargs: Any) -> None:  # pylint: disable=no-self-use
        tracer_provider = kwargs.get("tracer_provider") or trace.get_tracer_provider()
        tracer = trace.get_tracer(__name__, __version__, tracer_provider=tracer_provider)

        from llama_index.core.instrumentation import get_dispatcher  # pylint: disable=import-outside-toplevel

        from ._handler import EventHandler, _SpanHandler  # pylint: disable=import-outside-toplevel

        self._span_handler = _SpanHandler(
            tracer=tracer,
            separate_trace_from_runtime_context=bool(kwargs.get("separate_trace_from_runtime_context")),
        )
        self._event_handler = EventHandler(span_handler=self._span_handler)
        dispatcher = get_dispatcher()
        for span_handler in dispatcher.span_handlers:
            if isinstance(span_handler, type(self._span_handler)):
                break
        else:
            dispatcher.add_span_handler(self._span_handler)
        for event_handler in dispatcher.event_handlers:
            if isinstance(event_handler, type(self._event_handler)):
                break
        else:
            dispatcher.add_event_handler(self._event_handler)

    def _uninstrument(self, **kwargs: Any) -> None:
        if self._event_handler is None:
            return
        from llama_index.core.instrumentation import get_dispatcher  # pylint: disable=import-outside-toplevel

        dispatcher = get_dispatcher()
        dispatcher.span_handlers[:] = filter(
            lambda h: not isinstance(h, type(self._span_handler)),
            dispatcher.span_handlers,
        )
        dispatcher.event_handlers[:] = filter(
            lambda h: not isinstance(h, type(self._event_handler)),
            dispatcher.event_handlers,
        )
        self._event_handler = None
