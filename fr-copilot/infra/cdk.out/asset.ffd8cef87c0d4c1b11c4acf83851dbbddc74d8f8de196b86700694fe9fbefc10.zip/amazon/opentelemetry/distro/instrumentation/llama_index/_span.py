# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0
import inspect
import logging
from functools import singledispatchmethod
from typing import TYPE_CHECKING, Any, Callable, Dict, Iterable, Iterator, Mapping, Optional, Tuple, Union

from llama_index.core.agent.workflow import AgentWorkflow, BaseWorkflowAgent
from llama_index.core.base.embeddings.base import BaseEmbedding
from llama_index.core.base.llms.base import BaseLLM
from llama_index.core.base.llms.types import ChatMessage, ChatResponse, CompletionResponse, TextBlock

try:
    from llama_index.core.base.llms.types import ThinkingBlock
except ImportError:
    ThinkingBlock = None

try:
    from llama_index.core.base.llms.types import ToolCallBlock
except ImportError:
    ToolCallBlock = None

try:
    from llama_index.core.base.llms.types import ImageBlock
except ImportError:
    ImageBlock = None
from llama_index.core.instrumentation.events import BaseEvent
from llama_index.core.instrumentation.events.chat_engine import (
    StreamChatDeltaReceivedEvent,
    StreamChatEndEvent,
    StreamChatErrorEvent,
)
from llama_index.core.instrumentation.events.embedding import EmbeddingEndEvent, EmbeddingStartEvent
from llama_index.core.instrumentation.events.llm import (
    LLMChatEndEvent,
    LLMChatInProgressEvent,
    LLMChatStartEvent,
    LLMCompletionEndEvent,
    LLMCompletionInProgressEvent,
    LLMPredictStartEvent,
)
from llama_index.core.instrumentation.events.query import QueryStartEvent
from llama_index.core.instrumentation.events.rerank import ReRankStartEvent
from llama_index.core.instrumentation.events.retrieval import RetrievalStartEvent
from llama_index.core.instrumentation.events.synthesis import GetResponseStartEvent, SynthesizeStartEvent
from llama_index.core.instrumentation.span import BaseSpan
from llama_index.core.multi_modal_llms import MultiModalLLM
from llama_index.core.tools import FunctionTool  # type: ignore[attr-defined]
from llama_index.core.tools import BaseTool
from pydantic import PrivateAttr

from amazon.opentelemetry.distro.instrumentation.common.instrumentation_utils import (
    GEN_AI_WORKFLOW_NAME,
    OPERATION_INVOKE_WORKFLOW,
    content_to_parts,
    first_not_none,
    serialize_to_json_string,
    to_tool_attribute_value,
    try_detach,
)
from opentelemetry import context as context_api
from opentelemetry.semconv._incubating.attributes.error_attributes import ERROR_TYPE

# pylint: disable=unused-import
from opentelemetry.semconv._incubating.attributes.gen_ai_attributes import (  # noqa: F401
    GEN_AI_AGENT_DESCRIPTION,
    GEN_AI_AGENT_NAME,
    GEN_AI_EMBEDDINGS_DIMENSION_COUNT,
    GEN_AI_INPUT_MESSAGES,
    GEN_AI_OPERATION_NAME,
    GEN_AI_OUTPUT_MESSAGES,
    GEN_AI_PROVIDER_NAME,
    GEN_AI_REQUEST_CHOICE_COUNT,
    GEN_AI_REQUEST_FREQUENCY_PENALTY,
    GEN_AI_REQUEST_MAX_TOKENS,
    GEN_AI_REQUEST_MODEL,
    GEN_AI_REQUEST_PRESENCE_PENALTY,
    GEN_AI_REQUEST_SEED,
    GEN_AI_REQUEST_STOP_SEQUENCES,
    GEN_AI_REQUEST_STREAM,
    GEN_AI_REQUEST_TEMPERATURE,
    GEN_AI_REQUEST_TOP_K,
    GEN_AI_REQUEST_TOP_P,
    GEN_AI_RESPONSE_FINISH_REASONS,
    GEN_AI_RESPONSE_MODEL,
    GEN_AI_SYSTEM_INSTRUCTIONS,
    GEN_AI_TOOL_CALL_ARGUMENTS,
    GEN_AI_TOOL_CALL_RESULT,
    GEN_AI_TOOL_DEFINITIONS,
    GEN_AI_TOOL_DESCRIPTION,
    GEN_AI_TOOL_NAME,
    GEN_AI_USAGE_CACHE_CREATION_INPUT_TOKENS,
    GEN_AI_USAGE_CACHE_READ_INPUT_TOKENS,
    GEN_AI_USAGE_INPUT_TOKENS,
    GEN_AI_USAGE_OUTPUT_TOKENS,
    GEN_AI_USAGE_REASONING_OUTPUT_TOKENS,
    GenAiOperationNameValues,
)
from opentelemetry.trace import Span, Status, StatusCode, set_span_in_context
from opentelemetry.util.types import AttributeValue

logger = logging.getLogger(__name__)


_OPERATION_RERANK = "rerank"
_OPERATION_SYNTHESIZE = "synthesize"
_OPERATION_QUERY = "query"


if not TYPE_CHECKING:
    from llama_index.core.instrumentation.events.exception import ExceptionEvent


# Provider detection: (module_path, class_name, provider_string)
# Order matters — azure must come before openai since AzureOpenAI is a subclass of OpenAI.
_PROVIDER_IMPORTS = (
    ("llama_index.llms.azure_openai", "AzureOpenAI", "azure.ai.openai"),
    ("llama_index.llms.openai", "OpenAI", "openai"),
    ("llama_index.llms.anthropic", "Anthropic", "anthropic"),
    ("llama_index.llms.vertex", "Vertex", "gcp.vertex_ai"),
    ("llama_index.llms.bedrock_converse", "BedrockConverse", "aws.bedrock"),
)

# Fallback: match class name keywords when provider packages are not installed.
# Order matters — "azure" must come before "openai" since AzureOpenAI contains both.
_PROVIDER_CLASS_NAME_KEYWORDS = (
    (("azure", "openai"), "azure.ai.openai"),
    (("openai",), "openai"),
    (("anthropic",), "anthropic"),
    (("vertex",), "gcp.vertex_ai"),
    (("gemini",), "gcp.gemini"),
    (("bedrock",), "aws.bedrock"),
)


def _detect_llm_provider(instance: Any) -> Optional[str]:
    """Detect LLM provider from instance type or class name.

    Tries isinstance checks via lazy imports first, then falls back to
    matching keywords in the class name.
    """
    for module_path, cls_name, provider in _PROVIDER_IMPORTS:
        try:
            import importlib  # pylint: disable=import-outside-toplevel

            module = importlib.import_module(module_path)
            if isinstance(instance, getattr(module, cls_name)):
                return provider
        except (ImportError, AttributeError):
            pass

    class_name = instance.__class__.__name__.lower()
    for keywords, provider in _PROVIDER_CLASS_NAME_KEYWORDS:
        if all(kw in class_name for kw in keywords):
            return provider

    return None


def _safe_get(obj: Any, key: str) -> Any:
    """Get a value from an object that may be a dict or an object with attributes."""
    return obj.get(key) if isinstance(obj, Mapping) else getattr(obj, key, None)


def _message_to_parts(msg: ChatMessage) -> list:  # pylint: disable=too-many-branches
    """Convert a ChatMessage's blocks to OTel parts format."""
    blocks = getattr(msg, "blocks", None)
    if blocks:
        parts = []
        for block in blocks:
            if isinstance(block, TextBlock):
                parts.append({"type": "text", "content": block.text})
            elif ToolCallBlock is not None and isinstance(block, ToolCallBlock):
                part: dict = {"type": "tool_call"}
                if hasattr(block, "tool_name") and block.tool_name:
                    part["name"] = block.tool_name
                if hasattr(block, "tool_kwargs") and block.tool_kwargs:
                    part["arguments"] = block.tool_kwargs
                if hasattr(block, "tool_call_id") and block.tool_call_id:
                    part["id"] = block.tool_call_id
                parts.append(part)
            elif ThinkingBlock is not None and isinstance(block, ThinkingBlock):
                parts.append({"type": "reasoning", "content": str(block.content)})
            elif ImageBlock is not None and isinstance(block, ImageBlock):
                if getattr(block, "url", None):
                    parts.append({"type": "uri", "modality": "image", "uri": str(block.url)})
                elif getattr(block, "image", None) is not None:
                    image = block.image
                    parts.append(
                        {
                            "type": "blob",
                            "modality": "image",
                            "mime_type": getattr(block, "image_mimetype", None) or "image/*",
                            "content": image.decode() if isinstance(image, (bytes, bytearray)) else str(image),
                        }
                    )
                elif getattr(block, "path", None):
                    parts.append({"type": "uri", "modality": "image", "uri": str(block.path)})
        if parts:
            return parts
    return content_to_parts(getattr(msg, "content", ""))


def _format_messages(messages: Iterable[ChatMessage]) -> tuple:
    """Convert LlamaIndex ChatMessages to OTel GenAI semconv format.

    Returns (system_instructions, conversation) where:
    - system_instructions: list of {"type": "text", "content": "..."} for system messages
    - conversation: list of {"role": "...", "parts": [{"type": "text", "content": "..."}]}

    See:
    - https://opentelemetry.io/docs/specs/semconv/gen-ai/gen-ai-input-messages.json
    - https://opentelemetry.io/docs/specs/semconv/gen-ai/gen-ai-output-messages.json
    - https://opentelemetry.io/docs/specs/semconv/gen-ai/gen-ai-system-instructions.json
    """
    role_map = {"system": "system", "user": "user", "assistant": "assistant", "tool": "tool"}
    system_instructions = []
    conversation = []
    for msg in messages:
        raw_role = getattr(msg, "role", "user")
        # LlamaIndex uses MessageRole enum; extract the value string
        role = role_map.get(str(raw_role).rsplit(".", 1)[-1].lower(), str(raw_role))
        parts = _message_to_parts(msg)
        if role == "system":
            system_instructions.extend(parts)
        else:
            conversation.append({"role": role, "parts": parts})
    return system_instructions, conversation


class _Span(BaseSpan):
    _otel_span: Span = PrivateAttr()
    _attributes: Dict[str, AttributeValue] = PrivateAttr()
    _parent: Optional["_Span"] = PrivateAttr()
    _context_token: Optional[object] = PrivateAttr()
    _deferred: bool = PrivateAttr(default=False)
    _span_name: Optional[str] = PrivateAttr(default=None)

    def __init__(
        self,
        otel_span: Span,
        parent: Optional["_Span"] = None,
        context_token: Optional[object] = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self._otel_span = otel_span
        self._parent = parent
        self._attributes = {}
        self._context_token = context_token
        self._deferred = False

    @property
    def is_passthrough(self) -> bool:
        return False

    def set_deferred(self) -> None:
        # Streaming LLM calls return an async generator immediately, causing the
        # LlamaIndex dispatcher to exit the span before tokens are streamed.
        # Deferred spans stay open until a terminal event like LLMChatEndEvent
        # delivers token counts and output messages via _end_deferred.
        self._deferred = True

    def _end_deferred(self) -> None:
        if self._deferred:
            self.end()

    def __setitem__(self, key: str, value: AttributeValue) -> None:
        self._attributes[key] = value

    def record_exception(self, exception: BaseException) -> None:
        self._otel_span.record_exception(exception)

    def _get_span_name(self) -> str:
        if self._span_name:
            return self._span_name

        op = self._attributes.get(GEN_AI_OPERATION_NAME)
        # generic fallback if no operation name
        if not op:
            return "llama_index.operation"

        suffix = {
            GenAiOperationNameValues.INVOKE_AGENT.value: self._attributes.get(GEN_AI_AGENT_NAME),
            OPERATION_INVOKE_WORKFLOW: self._attributes.get(GEN_AI_WORKFLOW_NAME),
            GenAiOperationNameValues.EXECUTE_TOOL.value: self._attributes.get(GEN_AI_TOOL_NAME),
        }.get(op, self._attributes.get(GEN_AI_REQUEST_MODEL))

        return f"{op} {suffix}" if suffix else op

    def end(self, exception: Optional[BaseException] = None) -> None:
        if not self._otel_span.is_recording():
            return

        if self._context_token is not None:
            try_detach(self._context_token)  # type: ignore[arg-type]
            self._context_token = None

        if exception is None:
            status = Status(status_code=StatusCode.OK)
        else:
            self._otel_span.record_exception(exception)
            self._attributes[ERROR_TYPE] = type(exception).__name__
            # Follow the format in OTEL SDK for description, see:
            # https://github.com/open-telemetry/opentelemetry-python/blob/2b9dcfc5d853d1c10176937a6bcaade54cda1a31/opentelemetry-api/src/opentelemetry/trace/__init__.py#L588  # noqa E501
            description = f"{type(exception).__name__}: {exception}"
            status = Status(status_code=StatusCode.ERROR, description=description)

        self._otel_span.update_name(self._get_span_name())

        self._otel_span.set_status(status=status)
        self._otel_span.set_attributes(self._attributes)
        self._otel_span.end()

    @property
    def active(self) -> bool:
        return self._otel_span.is_recording()

    @property
    def context(self) -> context_api.Context:
        """OTel context with this span as the active span.

        Used by child spans to establish parent-child relationships:
            otel_span = tracer.start_span(name, context=parent.context)

        _PassthroughSpan overrides this to delegate to its parent's context,
        so child spans transparently skip over suppressed spans in the
        OTel trace tree. The recursion terminates when it reaches a real
        _Span (returns its own context) or a parentless passthrough
        (returns the ambient context).
        """
        return set_span_in_context(self._otel_span)

    def process_input(  # pylint: disable=too-many-locals,too-many-branches,too-many-statements
        self, instance: Any, bound_args: inspect.BoundArguments
    ) -> None:
        from llama_index.core.llms.function_calling import FunctionCallingLLM  # pylint: disable=import-outside-toplevel

        if isinstance(instance, FunctionCallingLLM):
            tools = bound_args.kwargs.get("tools")
            if isinstance(tools, Mapping):
                tool_items = tools.get("tools", [tools])
            elif isinstance(tools, Iterable) and not isinstance(tools, (str, bytes)):
                tool_items = tools
            else:
                tool_items = [tools]

            if isinstance(tool_items, Mapping):
                tool_items = [tool_items]

            tool_defs = []
            for tool in tool_items:
                metadata = getattr(tool, "metadata", None)
                to_openai_tool = getattr(metadata, "to_openai_tool", None)
                tool_candidates = []
                if callable(to_openai_tool):
                    try:
                        tool_candidates.append(to_openai_tool())
                    except Exception:  # pylint: disable=broad-exception-caught
                        pass
                if metadata is not None:
                    tool_candidates.append(metadata)
                tool_candidates.append(tool)

                for tool_candidate in tool_candidates:
                    if isinstance(tool_candidate, Mapping):
                        if isinstance(function := tool_candidate.get("function"), Mapping):
                            tool_candidate = function
                            tool_type = "function"
                        elif isinstance(tool_spec := tool_candidate.get("toolSpec"), Mapping):
                            tool_candidate = tool_spec
                            tool_type = "function"
                        else:
                            tool_type = tool_candidate.get("type") or "function"
                    else:
                        tool_type = _safe_get(tool_candidate, "type") or "function"

                    name = _safe_get(tool_candidate, "name")
                    if isinstance(name, str) and name:
                        tool = tool_candidate
                        break
                else:
                    continue

                tool_definition: dict[str, Any] = {"type": str(tool_type), "name": name}
                description = _safe_get(tool, "description")
                if isinstance(description, str) and description:
                    tool_definition["description"] = description

                parameters = _safe_get(tool, "parameters")
                if parameters is None:
                    input_schema = _safe_get(tool, "inputSchema")
                    parameters = _safe_get(input_schema, "json")
                if parameters is None:
                    fn_schema = _safe_get(tool, "fn_schema")
                    model_json_schema = getattr(fn_schema, "model_json_schema", None)
                    if callable(model_json_schema):
                        parameters = model_json_schema()
                if isinstance(parameters, Mapping):
                    tool_definition["parameters"] = dict(parameters)
                tool_defs.append(tool_definition)

            if tool_defs:
                self[GEN_AI_TOOL_DEFINITIONS] = serialize_to_json_string(tool_defs)

        if isinstance(instance, (BaseLLM, MultiModalLLM)):
            request_params = bound_args.kwargs
            fallback_params = {}
            max_tokens_fallback = None
            if self._attributes.get(GEN_AI_PROVIDER_NAME) in ("openai", "azure.ai.openai"):
                request_params = getattr(instance, "additional_kwargs", None) or {}
                fallback_params = bound_args.kwargs
                max_tokens_fallback = first_not_none(
                    getattr(instance, "max_tokens", None),
                    getattr(instance, "max_output_tokens", None),
                    getattr(instance, "max_completion_tokens", None),
                )

            temperature = first_not_none(
                request_params.get("temperature"),
                fallback_params.get("temperature"),
            )
            if temperature is not None:
                self[GEN_AI_REQUEST_TEMPERATURE] = temperature
            max_tokens = first_not_none(
                request_params.get("max_tokens"),
                request_params.get("max_output_tokens"),
                request_params.get("max_completion_tokens"),
                max_tokens_fallback,
                fallback_params.get("max_tokens"),
                fallback_params.get("max_output_tokens"),
                fallback_params.get("max_completion_tokens"),
            )
            if max_tokens is not None:
                self[GEN_AI_REQUEST_MAX_TOKENS] = max_tokens
            top_p = first_not_none(request_params.get("top_p"), fallback_params.get("top_p"))
            if top_p is not None:
                self[GEN_AI_REQUEST_TOP_P] = top_p
            top_k = first_not_none(request_params.get("top_k"), fallback_params.get("top_k"))
            if top_k is not None:
                self[GEN_AI_REQUEST_TOP_K] = top_k
            frequency_penalty = first_not_none(
                request_params.get("frequency_penalty"),
                fallback_params.get("frequency_penalty"),
            )
            if frequency_penalty is not None:
                self[GEN_AI_REQUEST_FREQUENCY_PENALTY] = frequency_penalty
            presence_penalty = first_not_none(
                request_params.get("presence_penalty"),
                fallback_params.get("presence_penalty"),
            )
            if presence_penalty is not None:
                self[GEN_AI_REQUEST_PRESENCE_PENALTY] = presence_penalty
            stop = first_not_none(
                request_params.get("stop_sequences"),
                request_params.get("stop"),
                fallback_params.get("stop_sequences"),
                fallback_params.get("stop"),
            )
            if stop is not None:
                self[GEN_AI_REQUEST_STOP_SEQUENCES] = [stop] if isinstance(stop, str) else stop
            seed = first_not_none(
                request_params.get("seed"),
                request_params.get("random_seed"),
                fallback_params.get("seed"),
                fallback_params.get("random_seed"),
            )
            if seed is not None:
                self[GEN_AI_REQUEST_SEED] = seed
            choice_count = first_not_none(
                request_params.get("choice_count"),
                request_params.get("n"),
                fallback_params.get("choice_count"),
                fallback_params.get("n"),
            )
            if choice_count is not None:
                self[GEN_AI_REQUEST_CHOICE_COUNT] = choice_count
            stream = first_not_none(
                request_params.get("stream"),
                request_params.get("streaming"),
                fallback_params.get("stream"),
                fallback_params.get("streaming"),
            )
            if stream is not None:
                self[GEN_AI_REQUEST_STREAM] = stream

        # Capture tool call arguments for FunctionTool invocations
        if isinstance(instance, (BaseTool, FunctionTool)):
            kwargs = bound_args.kwargs
            if kwargs:
                self[GEN_AI_TOOL_CALL_ARGUMENTS] = to_tool_attribute_value(kwargs)

        if isinstance(instance, BaseWorkflowAgent):
            start_event = bound_args.arguments.get("start_event")
            user_msg = start_event.get("user_msg") if hasattr(start_event, "get") else None
            if user_msg:
                _, conversation = _format_messages([ChatMessage(role="user", content=user_msg)])
                if conversation:
                    self[GEN_AI_INPUT_MESSAGES] = serialize_to_json_string(conversation)

    def process_agent_setup_input(self, agent_setup: Any) -> None:
        """Capture agent-step input messages on a run_agent_step invoke_agent span."""
        messages = getattr(agent_setup, "input", None)
        if not messages:
            return
        system_instructions, conversation = _format_messages(messages)
        if system_instructions:
            self[GEN_AI_SYSTEM_INSTRUCTIONS] = serialize_to_json_string(system_instructions)
        if conversation:
            self[GEN_AI_INPUT_MESSAGES] = serialize_to_json_string(conversation)

    def process_agent_output(self, result: Any) -> None:
        """Capture the final agent output on the invoke_agent span."""
        response = getattr(getattr(result, "result", None), "response", None)
        if response is None:
            if getattr(result, "tool_calls", None):
                return
            response = getattr(result, "response", None)
        if not isinstance(response, ChatMessage):
            return
        _, conversation = _format_messages([response])
        if conversation:
            conversation[-1].setdefault("finish_reason", "stop")
            self[GEN_AI_OUTPUT_MESSAGES] = serialize_to_json_string(conversation)

    @singledispatchmethod
    def process_instance(self, instance: Any) -> None: ...  # noqa: E704  # pylint: disable=no-self-use

    @process_instance.register(BaseLLM)
    @process_instance.register(MultiModalLLM)
    def _(  # pylint: disable=too-many-locals,too-many-branches,too-many-statements
        self, instance: Union[BaseLLM, MultiModalLLM]
    ) -> None:
        if metadata := instance.metadata:
            self[GEN_AI_REQUEST_MODEL] = metadata.model_name

        # Add LLM provider detection
        if provider := _detect_llm_provider(instance):
            self[GEN_AI_PROVIDER_NAME] = provider

        # Capture temperature if available
        if hasattr(instance, "temperature") and instance.temperature is not None:
            self[GEN_AI_REQUEST_TEMPERATURE] = instance.temperature

        additional_kwargs = getattr(instance, "additional_kwargs", None) or {}
        max_tokens = first_not_none(
            getattr(instance, "max_tokens", None),
            getattr(instance, "max_output_tokens", None),
            getattr(instance, "max_completion_tokens", None),
            additional_kwargs.get("max_tokens"),
            additional_kwargs.get("max_output_tokens"),
            additional_kwargs.get("max_completion_tokens"),
        )
        if max_tokens is not None:
            self[GEN_AI_REQUEST_MAX_TOKENS] = max_tokens
        if (top_p := additional_kwargs.get("top_p")) is not None:
            self[GEN_AI_REQUEST_TOP_P] = top_p
        if (top_k := additional_kwargs.get("top_k")) is not None:
            self[GEN_AI_REQUEST_TOP_K] = top_k
        if (frequency_penalty := additional_kwargs.get("frequency_penalty")) is not None:
            self[GEN_AI_REQUEST_FREQUENCY_PENALTY] = frequency_penalty
        if (presence_penalty := additional_kwargs.get("presence_penalty")) is not None:
            self[GEN_AI_REQUEST_PRESENCE_PENALTY] = presence_penalty
        if stop := (additional_kwargs.get("stop") or additional_kwargs.get("stop_sequences")):
            self[GEN_AI_REQUEST_STOP_SEQUENCES] = stop
        if (seed := additional_kwargs.get("seed")) is not None:
            self[GEN_AI_REQUEST_SEED] = seed
        choice_count = first_not_none(additional_kwargs.get("choice_count"), additional_kwargs.get("n"))
        if choice_count is not None:
            self[GEN_AI_REQUEST_CHOICE_COUNT] = choice_count
        if (stream := additional_kwargs.get("stream")) is not None:
            self[GEN_AI_REQUEST_STREAM] = stream

        top_p = first_not_none(getattr(instance, "top_p", None), additional_kwargs.get("top_p"))
        if top_p is not None:
            self[GEN_AI_REQUEST_TOP_P] = top_p
        top_k = first_not_none(getattr(instance, "top_k", None), additional_kwargs.get("top_k"))
        if top_k is not None:
            self[GEN_AI_REQUEST_TOP_K] = top_k
        frequency_penalty = first_not_none(
            getattr(instance, "frequency_penalty", None),
            additional_kwargs.get("frequency_penalty"),
        )
        if frequency_penalty is not None:
            self[GEN_AI_REQUEST_FREQUENCY_PENALTY] = frequency_penalty
        presence_penalty = first_not_none(
            getattr(instance, "presence_penalty", None),
            additional_kwargs.get("presence_penalty"),
        )
        if presence_penalty is not None:
            self[GEN_AI_REQUEST_PRESENCE_PENALTY] = presence_penalty
        stop = first_not_none(
            getattr(instance, "stop_sequences", None),
            getattr(instance, "stop", None),
            additional_kwargs.get("stop_sequences"),
            additional_kwargs.get("stop"),
        )
        if stop is not None:
            self[GEN_AI_REQUEST_STOP_SEQUENCES] = [stop] if isinstance(stop, str) else stop
        seed = first_not_none(
            getattr(instance, "seed", None),
            getattr(instance, "random_seed", None),
            additional_kwargs.get("seed"),
            additional_kwargs.get("random_seed"),
        )
        if seed is not None:
            self[GEN_AI_REQUEST_SEED] = seed
        choice_count = first_not_none(
            getattr(instance, "choice_count", None),
            getattr(instance, "n", None),
            additional_kwargs.get("choice_count"),
            additional_kwargs.get("n"),
        )
        if choice_count is not None:
            self[GEN_AI_REQUEST_CHOICE_COUNT] = choice_count
        instance_stream = getattr(instance, "stream", None)
        stream = first_not_none(
            None if callable(instance_stream) else instance_stream,
            getattr(instance, "streaming", None),
            additional_kwargs.get("stream"),
            additional_kwargs.get("streaming"),
        )
        if stream is not None:
            self[GEN_AI_REQUEST_STREAM] = stream

    @process_instance.register
    def _(self, instance: BaseEmbedding) -> None:
        if name := instance.model_name:
            self[GEN_AI_REQUEST_MODEL] = name

    @process_instance.register
    def _(self, instance: BaseTool) -> None:
        self[GEN_AI_OPERATION_NAME] = GenAiOperationNameValues.EXECUTE_TOOL.value
        metadata = instance.metadata
        self[GEN_AI_TOOL_DESCRIPTION] = metadata.description
        try:
            self[GEN_AI_TOOL_NAME] = metadata.get_name()
        except BaseException:
            pass

    def process_event(self, event: BaseEvent) -> None:
        self._process_event(event)

    @singledispatchmethod
    def _process_event(self, event: BaseEvent) -> None: ...  # noqa: E704  # pylint: disable=no-self-use

    @_process_event.register
    def _(self, event: ExceptionEvent) -> None: ...  # noqa: E704  # pylint: disable=no-self-use

    @_process_event.register
    def _(self, event: EmbeddingStartEvent) -> None:
        self[GEN_AI_OPERATION_NAME] = GenAiOperationNameValues.EMBEDDINGS.value

    @_process_event.register
    def _(self, event: EmbeddingEndEvent) -> None:
        self[GEN_AI_OPERATION_NAME] = GenAiOperationNameValues.EMBEDDINGS.value
        if event.embeddings and len(event.embeddings) > 0:
            first_embedding = event.embeddings[0]
            if hasattr(first_embedding, "__len__"):
                self[GEN_AI_EMBEDDINGS_DIMENSION_COUNT] = len(first_embedding)

    @_process_event.register
    def _(self, event: StreamChatDeltaReceivedEvent) -> None: ...  # noqa: E704  # pylint: disable=no-self-use

    @_process_event.register
    def _(self, event: StreamChatErrorEvent) -> None:
        self.record_exception(event.exception)
        if self._deferred:
            self.end(event.exception)

    @_process_event.register
    def _(self, event: StreamChatEndEvent) -> None:
        self[GEN_AI_OPERATION_NAME] = GenAiOperationNameValues.CHAT.value
        self._end_deferred()

    @_process_event.register
    def _(self, event: LLMPredictStartEvent) -> None:
        self[GEN_AI_OPERATION_NAME] = GenAiOperationNameValues.TEXT_COMPLETION.value

    @_process_event.register
    def _(self, event: LLMCompletionInProgressEvent) -> None: ...  # noqa: E704  # pylint: disable=no-self-use

    @_process_event.register
    def _(self, event: LLMCompletionEndEvent) -> None:
        self[GEN_AI_OPERATION_NAME] = GenAiOperationNameValues.TEXT_COMPLETION.value
        self._extract_token_counts(event.response)
        self._extract_response_model(event.response)
        self._end_deferred()

    @_process_event.register
    def _(self, event: LLMChatStartEvent) -> None:
        self[GEN_AI_OPERATION_NAME] = GenAiOperationNameValues.CHAT.value
        system_instructions, conversation = _format_messages(event.messages)
        if system_instructions:
            self[GEN_AI_SYSTEM_INSTRUCTIONS] = serialize_to_json_string(system_instructions)
        if conversation:
            self[GEN_AI_INPUT_MESSAGES] = serialize_to_json_string(conversation)

    @_process_event.register
    def _(self, event: LLMChatInProgressEvent) -> None: ...  # noqa: E704  # pylint: disable=no-self-use

    @_process_event.register
    def _(self, event: LLMChatEndEvent) -> None:
        self[GEN_AI_OPERATION_NAME] = GenAiOperationNameValues.CHAT.value
        if (response := event.response) is None:
            self._end_deferred()
            return
        self._extract_token_counts(response)
        self._extract_response_model(response)
        finish_reason = self._extract_finish_reason(response)
        _, output = _format_messages([response.message])
        if output:
            # Output messages require finish_reason per OTel semconv
            default_reason = finish_reason or "stop"
            for msg in output:
                msg.setdefault("finish_reason", default_reason)
            self[GEN_AI_OUTPUT_MESSAGES] = serialize_to_json_string(output)
        if finish_reason:
            self[GEN_AI_RESPONSE_FINISH_REASONS] = [finish_reason]
        self._end_deferred()

    @_process_event.register
    def _(self, event: ReRankStartEvent) -> None:
        self[GEN_AI_OPERATION_NAME] = _OPERATION_RERANK
        self[GEN_AI_REQUEST_MODEL] = event.model_name

    @_process_event.register
    def _(self, event: QueryStartEvent) -> None:
        self[GEN_AI_OPERATION_NAME] = _OPERATION_QUERY

    @_process_event.register
    def _(self, event: RetrievalStartEvent) -> None:
        self[GEN_AI_OPERATION_NAME] = GenAiOperationNameValues.RETRIEVAL.value

    @_process_event.register
    def _(self, event: SynthesizeStartEvent) -> None:
        self[GEN_AI_OPERATION_NAME] = _OPERATION_SYNTHESIZE

    @_process_event.register
    def _(self, event: GetResponseStartEvent) -> None:
        self[GEN_AI_OPERATION_NAME] = _OPERATION_SYNTHESIZE

    def _extract_response_model(self, response: Union[ChatResponse, CompletionResponse]) -> None:
        raw = getattr(response, "raw", None)
        if raw is None:
            return
        model = _safe_get(raw, "model")
        if model:
            self[GEN_AI_RESPONSE_MODEL] = model

    @staticmethod
    def _extract_finish_reason(response: Union[ChatResponse, CompletionResponse]) -> Optional[str]:
        """Extract finish reason from the raw response, returning None if not found."""
        raw = getattr(response, "raw", None)
        if raw is None:
            return None
        try:
            choices = _safe_get(raw, "choices") or _safe_get(raw, "candidates")
            if isinstance(choices, (list, tuple)) and choices:
                first = choices[0]
                reason = _safe_get(first, "finish_reason") or _safe_get(first, "finishReason")
                if reason:
                    return str(reason)

            reason = _safe_get(raw, "stop_reason") or _safe_get(raw, "stopReason")
            if reason:
                return str(reason)
        except Exception:  # pylint: disable=broad-exception-caught
            pass
        return None

    def _extract_token_counts(self, response: Union[ChatResponse, CompletionResponse]) -> None:
        if raw := getattr(response, "raw", None):
            usage = raw.get("usage") if isinstance(raw, Mapping) else getattr(raw, "usage", None)
            if usage:
                for attr_key, attr_val in _get_token_counts(usage):
                    self[attr_key] = attr_val
            if (
                (model_extra := getattr(raw, "model_extra", None))
                and hasattr(model_extra, "get")
                and (x_groq := model_extra.get("x_groq"))
                and hasattr(x_groq, "get")
                and (usage := x_groq.get("usage"))
            ):
                for attr_key, attr_val in _get_token_counts(usage):
                    self[attr_key] = attr_val

            # Check for VertexAI usage_metadata
            # VertexAI stores usage_metadata inside _raw_response
            if isinstance(raw, Mapping) and (raw_response := raw.get("_raw_response")):
                usage_metadata = (
                    raw_response.get("usage_metadata")
                    if isinstance(raw_response, Mapping)
                    else getattr(raw_response, "usage_metadata", None)
                )
            else:
                usage_metadata = getattr(raw, "usage_metadata", None)
            if usage_metadata:
                for attr_key, attr_val in _get_token_counts(usage_metadata):
                    self[attr_key] = attr_val
        # Look for token counts in additional_kwargs of the completion payload
        # This is needed for non-OpenAI models
        if additional_kwargs := getattr(response, "additional_kwargs", None):
            for attr_key, attr_val in _get_token_counts(additional_kwargs):
                self[attr_key] = attr_val

    @process_instance.register(FunctionTool)
    def _(self, instance: FunctionTool) -> None:
        self[GEN_AI_OPERATION_NAME] = GenAiOperationNameValues.EXECUTE_TOOL.value
        metadata = instance.metadata
        self[GEN_AI_TOOL_DESCRIPTION] = metadata.description
        try:
            self[GEN_AI_TOOL_NAME] = metadata.get_name()
        except BaseException:
            pass

    @process_instance.register(BaseWorkflowAgent)
    def _(self, instance: BaseWorkflowAgent) -> None:
        self[GEN_AI_OPERATION_NAME] = GenAiOperationNameValues.INVOKE_AGENT.value
        if hasattr(instance, "name") and instance.name:
            self[GEN_AI_AGENT_NAME] = instance.name
        if hasattr(instance, "description") and instance.description:
            self[GEN_AI_AGENT_DESCRIPTION] = instance.description

    @process_instance.register(AgentWorkflow)
    def _(self, instance: AgentWorkflow) -> None:
        self[GEN_AI_OPERATION_NAME] = OPERATION_INVOKE_WORKFLOW
        workflow_name = getattr(instance, "workflow_name", None)
        if workflow_name:
            self[GEN_AI_WORKFLOW_NAME] = workflow_name


class _PassthroughSpan(_Span):
    """A span that maintains the parent chain but produces no OTel span.

    Suppressed methods (e.g. _query, _retrieve) get a passthrough span so that:
    - Child spans can find their grandparent's OTel context via parent.context
    - The notify_parent chain remains intact for streaming propagation
    - No spurious "Open span is missing" warnings are logged on exit
    """

    def __init__(self, parent: Optional[_Span] = None, **kwargs: Any) -> None:
        from opentelemetry.trace import INVALID_SPAN  # pylint: disable=import-outside-toplevel

        super().__init__(otel_span=INVALID_SPAN, parent=parent, **kwargs)

    @property
    def is_passthrough(self) -> bool:
        return True

    @property
    def context(self) -> context_api.Context:
        # Delegate to parent's context so child spans skip over this
        # invisible span. Recurses up through any chain of passthrough
        # spans until it hits a real _Span (which returns its own OTel
        # context) or runs out of parents (falls back to ambient context).
        if self._parent:
            return self._parent.context
        return context_api.get_current()

    def end(self, exception: Optional[BaseException] = None) -> None:
        pass

    def __setitem__(self, key: str, value: AttributeValue) -> None:
        pass

    def record_exception(self, exception: BaseException) -> None:
        pass

    def process_input(self, instance: Any, bound_args: inspect.BoundArguments) -> None:
        pass

    def process_instance(self, instance: Any) -> None:
        pass

    def process_event(self, event: BaseEvent) -> None:
        pass


def _get_token_counts(usage: Union[object, Mapping[str, Any]]) -> Iterator[Tuple[str, Any]]:
    if isinstance(usage, Mapping):
        return _get_token_counts_from_mapping(usage)
    return _get_token_counts_from_object(usage)


def _get_token_counts_from_object(usage: object) -> Iterator[Tuple[str, Any]]:
    def get_value(obj: object, key: str) -> Any:
        return getattr(obj, key, None)

    yield from _get_token_counts_impl(usage, get_value)


def _get_token_counts_from_mapping(
    usage_mapping: Mapping[str, Any],
) -> Iterator[Tuple[str, Any]]:
    def get_value(obj: Mapping[str, Any], key: str) -> Any:
        return obj.get(key)

    yield from _get_token_counts_impl(usage_mapping, get_value)


def _get_token_counts_impl(  # pylint: disable=too-many-branches,too-many-statements
    usage: Union[object, Mapping[str, Any]], get_value: Callable[[Any, str], Any]
) -> Iterator[Tuple[str, Any]]:
    # OpenAI
    if (prompt_tokens := get_value(usage, "prompt_tokens")) is not None:
        try:
            yield GEN_AI_USAGE_INPUT_TOKENS, int(prompt_tokens)
        except BaseException:
            pass
    if (completion_tokens := get_value(usage, "completion_tokens")) is not None:
        try:
            yield GEN_AI_USAGE_OUTPUT_TOKENS, int(completion_tokens)
        except BaseException:
            pass

    # Anthropic
    if (output_tokens := get_value(usage, "output_tokens")) is not None:
        try:
            yield GEN_AI_USAGE_OUTPUT_TOKENS, int(output_tokens)
        except BaseException:
            pass
    if (input_tokens := get_value(usage, "input_tokens")) is not None:
        try:
            yield GEN_AI_USAGE_INPUT_TOKENS, int(input_tokens)
        except BaseException:
            pass

    # VertexAI
    if (prompt_token_count := get_value(usage, "prompt_token_count")) is not None:
        try:
            yield GEN_AI_USAGE_INPUT_TOKENS, int(prompt_token_count)
        except BaseException:
            pass
    if (candidates_token_count := get_value(usage, "candidates_token_count")) is not None:
        try:
            yield GEN_AI_USAGE_OUTPUT_TOKENS, int(candidates_token_count)
        except BaseException:
            pass

    input_token_details = first_not_none(
        get_value(usage, "input_token_details"),
        get_value(usage, "input_tokens_details"),
        get_value(usage, "prompt_tokens_details"),
    )
    output_token_details = first_not_none(
        get_value(usage, "output_token_details"),
        get_value(usage, "output_tokens_details"),
        get_value(usage, "completion_tokens_details"),
    )
    cache_read_input_tokens = first_not_none(
        get_value(usage, "cached_prompt_tokens"),
        get_value(usage, "cache_read_input_tokens"),
        _safe_get(input_token_details, "cache_read"),
        _safe_get(input_token_details, "cached_tokens"),
    )
    if cache_read_input_tokens is not None:
        try:
            yield GEN_AI_USAGE_CACHE_READ_INPUT_TOKENS, int(cache_read_input_tokens)
        except BaseException:
            pass
    cache_creation_input_tokens = first_not_none(
        get_value(usage, "cache_creation_tokens"),
        get_value(usage, "cache_creation_input_tokens"),
        _safe_get(input_token_details, "cache_creation"),
        _safe_get(input_token_details, "cache_write_tokens"),
    )
    if cache_creation_input_tokens is not None:
        try:
            yield GEN_AI_USAGE_CACHE_CREATION_INPUT_TOKENS, int(cache_creation_input_tokens)
        except BaseException:
            pass
    reasoning_output_tokens = first_not_none(
        get_value(usage, "reasoning_tokens"),
        _safe_get(output_token_details, "reasoning"),
        _safe_get(output_token_details, "reasoning_tokens"),
    )
    if reasoning_output_tokens is not None:
        try:
            yield GEN_AI_USAGE_REASONING_OUTPUT_TOKENS, int(reasoning_output_tokens)
        except BaseException:
            pass
