# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0

import re
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Dict, Optional, Tuple

from amazon.opentelemetry.distro.instrumentation.common.instrumentation_utils import (
    GEN_AI_WORKFLOW_NAME,
    OPERATION_INVOKE_WORKFLOW,
    PROVIDER_MAP,
    DictWithLock,
    content_to_parts,
    first_not_none,
    serialize_to_json_string,
    skip_instrumentation_if_suppressed,
    to_tool_attribute_value,
    try_detach,
)
from opentelemetry import context, trace
from opentelemetry.semconv._incubating.attributes.gen_ai_attributes import (
    GEN_AI_AGENT_DESCRIPTION,
    GEN_AI_AGENT_ID,
    GEN_AI_AGENT_NAME,
    GEN_AI_INPUT_MESSAGES,
    GEN_AI_OPERATION_NAME,
    GEN_AI_OUTPUT_MESSAGES,
    GEN_AI_PROVIDER_NAME,
    GEN_AI_REQUEST_CHOICE_COUNT,
    GEN_AI_REQUEST_FREQUENCY_PENALTY,
    GEN_AI_REQUEST_MAX_TOKENS,
    GEN_AI_REQUEST_MODEL,
    GEN_AI_REQUEST_PRESENCE_PENALTY,
    GEN_AI_REQUEST_SEED,
    GEN_AI_REQUEST_STOP_SEQUENCES,
    GEN_AI_REQUEST_STREAM,
    GEN_AI_REQUEST_TEMPERATURE,
    GEN_AI_REQUEST_TOP_K,
    GEN_AI_REQUEST_TOP_P,
    GEN_AI_RESPONSE_FINISH_REASONS,
    GEN_AI_RESPONSE_ID,
    GEN_AI_RESPONSE_MODEL,
    GEN_AI_SYSTEM_INSTRUCTIONS,
    GEN_AI_TOOL_CALL_ARGUMENTS,
    GEN_AI_TOOL_CALL_RESULT,
    GEN_AI_TOOL_DEFINITIONS,
    GEN_AI_TOOL_DESCRIPTION,
    GEN_AI_TOOL_NAME,
    GEN_AI_TOOL_TYPE,
    GEN_AI_USAGE_CACHE_CREATION_INPUT_TOKENS,
    GEN_AI_USAGE_CACHE_READ_INPUT_TOKENS,
    GEN_AI_USAGE_INPUT_TOKENS,
    GEN_AI_USAGE_OUTPUT_TOKENS,
    GEN_AI_USAGE_REASONING_OUTPUT_TOKENS,
    GenAiOperationNameValues,
)
from opentelemetry.semconv.attributes.error_attributes import ERROR_TYPE
from opentelemetry.trace import SpanKind, Status, StatusCode

if TYPE_CHECKING:
    from crewai.agents.agent_builder.base_agent import BaseAgent
    from crewai.crew import Crew
    from crewai.events.base_events import BaseEvent
    from crewai.events.types.agent_events import (
        AgentExecutionCompletedEvent,
        AgentExecutionErrorEvent,
        AgentExecutionStartedEvent,
    )
    from crewai.events.types.crew_events import (
        CrewKickoffCompletedEvent,
        CrewKickoffFailedEvent,
        CrewKickoffStartedEvent,
    )
    from crewai.events.types.llm_events import LLMCallCompletedEvent, LLMCallFailedEvent, LLMCallStartedEvent
    from crewai.events.types.tool_usage_events import ToolUsageErrorEvent, ToolUsageFinishedEvent, ToolUsageStartedEvent
    from crewai.llms.base_llm import BaseLLM
    from crewai.tools.tool_usage import ToolUsage
    from crewai.types.usage_metrics import UsageMetrics


@dataclass
class _SpanEntry:
    span: trace.Span
    token: Any
    root_event_id: str
    # older CrewAI versions only expose cumulative token usage, so retain the
    # starting counts to calculate this LLM call's usage when the span ends
    initial_token_usage: Tuple[int, int] = (0, 0)


class _EventBusEmitWrapper:
    """Wrapper for crewai_event_bus.emit that runs our event handler synchronously."""

    def __init__(self, event_handler: "OpenTelemetryEventHandler"):
        self._event_handler = event_handler

    def __call__(self, wrapped, instance, args, kwargs) -> Any:
        # pylint: disable=import-outside-toplevel
        from crewai.events.base_events import BaseEvent
        from crewai.events.types.tool_usage_events import ToolUsageStartedEvent

        event = args[1] if len(args) > 1 else kwargs.get("event")
        source = args[0] if args else kwargs.get("source")

        if isinstance(event, ToolUsageStartedEvent):
            self._event_handler._maybe_end_pending_llm_span_for_tool_call(source, event)

        result = wrapped(*args, **kwargs)
        if not isinstance(event, BaseEvent):
            return result

        self._event_handler._handle_event(source, event)
        return result


class OpenTelemetryEventHandler:

    def __init__(self, tracer: trace.Tracer) -> None:
        # pylint: disable=import-outside-toplevel
        from crewai.events.types.agent_events import (
            AgentExecutionCompletedEvent,
            AgentExecutionErrorEvent,
            AgentExecutionStartedEvent,
        )
        from crewai.events.types.crew_events import (
            CrewKickoffCompletedEvent,
            CrewKickoffFailedEvent,
            CrewKickoffStartedEvent,
        )
        from crewai.events.types.llm_events import LLMCallCompletedEvent, LLMCallFailedEvent, LLMCallStartedEvent
        from crewai.events.types.tool_usage_events import (
            ToolUsageErrorEvent,
            ToolUsageFinishedEvent,
            ToolUsageStartedEvent,
        )

        self._tracer = tracer
        # a map of every event's id to its span. If the event does not
        # create a span, then it's mapped to the span created by its nearest ancestor event
        self._event_id_to_span = DictWithLock()
        # maps each task or agent ID to the started event ID of its unfinished LLM call
        self._task_or_agent_id_to_started_llm_event_id = DictWithLock()
        self._event_type_handlers: Dict[type, Any] = {
            CrewKickoffStartedEvent: self._on_crew_start,
            CrewKickoffCompletedEvent: self._on_crew_completed,
            CrewKickoffFailedEvent: self._on_crew_failed,
            AgentExecutionStartedEvent: self._on_agent_start,
            AgentExecutionCompletedEvent: self._on_agent_completed,
            AgentExecutionErrorEvent: self._on_agent_failed,
            ToolUsageStartedEvent: self._on_tool_start,
            ToolUsageFinishedEvent: self._on_tool_finished,
            ToolUsageErrorEvent: self._on_tool_error,
            LLMCallStartedEvent: self._on_llm_start,
            LLMCallCompletedEvent: self._on_llm_completed,
            LLMCallFailedEvent: self._on_llm_failed,
        }

    @skip_instrumentation_if_suppressed
    def _handle_event(self, source: Any, event: "BaseEvent") -> None:
        handler = self._event_type_handlers.get(type(event))
        if handler:
            handler(source, event)
        else:
            event_id = getattr(event, "event_id", None)
            parent_event_id = getattr(event, "parent_event_id", None)
            parent_entry = self._event_id_to_span.get(parent_event_id) if parent_event_id else None
            if parent_entry is None and (source_id := getattr(source, "id", None)):
                parent_entry = self._event_id_to_span.get(str(source_id))
            if event_id and parent_entry:
                self._event_id_to_span.put(event_id, parent_entry)

    def _on_crew_start(self, source: "Crew", event: "CrewKickoffStartedEvent") -> None:
        crew_name = getattr(source, "name", None)
        span_name = f"{OPERATION_INVOKE_WORKFLOW} {crew_name}" if crew_name else OPERATION_INVOKE_WORKFLOW
        attributes: Dict[str, Any] = {
            GEN_AI_OPERATION_NAME: OPERATION_INVOKE_WORKFLOW,
        }
        if crew_name:
            attributes[GEN_AI_WORKFLOW_NAME] = crew_name
        if hasattr(source, "id"):
            attributes[GEN_AI_AGENT_ID] = str(source.id)

        agents = getattr(source, "agents", [])
        if agents:
            all_tools = []
            for agent in agents:
                all_tools.extend(getattr(agent, "tools", []) or [])
            if all_tools:
                tool_defs = self._extract_tool_definitions(all_tools)
                if tool_defs:
                    attributes[GEN_AI_TOOL_DEFINITIONS] = serialize_to_json_string(tool_defs)

        self._start_span(
            span_name,
            event.event_id,
            attributes,
            event.parent_event_id,
            root_event_id=event.event_id,
        )
        crew_entry = self._event_id_to_span.get(event.event_id)
        if crew_entry:
            if crew_id := getattr(source, "id", None):
                self._event_id_to_span.put(str(crew_id), crew_entry)
            for task in getattr(source, "tasks", None) or []:
                if task_id := getattr(task, "id", None):
                    self._event_id_to_span.put(str(task_id), crew_entry)

    def _on_crew_completed(self, source: "Crew", event: "CrewKickoffCompletedEvent") -> None:
        crew_entry = self._event_id_to_span.get(event.started_event_id)
        if crew_entry is None and (crew_id := getattr(source, "id", None)):
            crew_entry = self._event_id_to_span.get(str(crew_id))
        self._end_spans_for_root_event(crew_entry.root_event_id if crew_entry else event.started_event_id)

    def _on_crew_failed(self, source: "Crew", event: "CrewKickoffFailedEvent") -> None:
        crew_entry = self._event_id_to_span.get(event.started_event_id)
        if crew_entry is None and (crew_id := getattr(source, "id", None)):
            crew_entry = self._event_id_to_span.get(str(crew_id))
        self._end_spans_for_root_event(
            crew_entry.root_event_id if crew_entry else event.started_event_id,
            error=getattr(event, "error", None),
        )

    def _on_agent_start(  # pylint: disable=too-many-branches
        self, source: "BaseAgent", event: "AgentExecutionStartedEvent"  # pylint: disable=unused-argument
    ) -> None:
        agent = getattr(event, "agent", None)
        agent_role = getattr(agent, "role", None) if agent else None
        span_name = (
            f"{GenAiOperationNameValues.INVOKE_AGENT.value} {agent_role}"
            if agent_role
            else GenAiOperationNameValues.INVOKE_AGENT.value
        )
        attributes: Dict[str, Any] = {
            GEN_AI_OPERATION_NAME: GenAiOperationNameValues.INVOKE_AGENT.value,
        }
        if agent:
            if agent_role:
                attributes[GEN_AI_AGENT_NAME] = agent_role
            if hasattr(agent, "id"):
                attributes[GEN_AI_AGENT_ID] = str(agent.id)
            goal = getattr(agent, "goal", None)
            if goal:
                attributes[GEN_AI_AGENT_DESCRIPTION] = goal

            llm = getattr(agent, "llm", None)
            provider, model = self._extract_provider_and_model(llm)
            if provider:
                attributes[GEN_AI_PROVIDER_NAME] = provider
            if model:
                attributes[GEN_AI_REQUEST_MODEL] = model
            if llm:
                self._set_llm_request_span_attributes(attributes, llm)

        task_prompt = getattr(event, "task_prompt", None)
        if task_prompt:
            attributes[GEN_AI_INPUT_MESSAGES] = serialize_to_json_string(
                [{"role": "user", "parts": content_to_parts(task_prompt)}]
            )

        self._start_span(span_name, event.event_id, attributes, self._get_parent_event_id(event))
        if agent_entry := self._event_id_to_span.get(event.event_id):
            self._event_id_to_span.put(self._get_task_or_agent_id(event), agent_entry)

    def _on_agent_completed(
        self, source: "BaseAgent", event: "AgentExecutionCompletedEvent"  # pylint: disable=unused-argument
    ) -> None:
        attrs: Dict[str, Any] = {}
        output = getattr(event, "output", None)
        if output:
            attrs[GEN_AI_OUTPUT_MESSAGES] = serialize_to_json_string(
                [{"role": "assistant", "parts": content_to_parts(output), "finish_reason": "stop"}]
            )
        task_or_agent_id = self._get_task_or_agent_id(event)
        self._end_span(
            task_or_agent_id if self._event_id_to_span.get(task_or_agent_id) else event.started_event_id,
            attrs,
        )

    def _on_agent_failed(
        self, source: "BaseAgent", event: "AgentExecutionErrorEvent"
    ) -> None:  # pylint: disable=unused-argument
        task_or_agent_id = self._get_task_or_agent_id(event)
        self._end_span(
            task_or_agent_id if self._event_id_to_span.get(task_or_agent_id) else event.started_event_id,
            error=getattr(event, "error", None),
        )

    def _on_tool_start(self, source: "ToolUsage", event: "ToolUsageStartedEvent") -> None:
        tool_name = event.tool_name
        span_name = (
            f"{GenAiOperationNameValues.EXECUTE_TOOL.value} {tool_name}"
            if tool_name
            else GenAiOperationNameValues.EXECUTE_TOOL.value
        )
        attributes: Dict[str, Any] = {
            GEN_AI_OPERATION_NAME: GenAiOperationNameValues.EXECUTE_TOOL.value,
            GEN_AI_TOOL_TYPE: "function",
        }
        if tool_name:
            attributes[GEN_AI_TOOL_NAME] = tool_name

        desc = self._find_tool_description(source, event, tool_name)
        if desc:
            attributes[GEN_AI_TOOL_DESCRIPTION] = desc

        agent = first_not_none(getattr(source, "agent", None), self._get_event_agent(event))
        if agent:
            llm = getattr(agent, "llm", None)
            provider, model = self._extract_provider_and_model(llm)
            if provider:
                attributes[GEN_AI_PROVIDER_NAME] = provider
            if model:
                attributes[GEN_AI_REQUEST_MODEL] = model

        if event.tool_args:
            attributes[GEN_AI_TOOL_CALL_ARGUMENTS] = to_tool_attribute_value(event.tool_args)

        self._start_span(
            span_name,
            event.event_id,
            attributes,
            self._get_parent_event_id(event),
        )

    def _on_tool_finished(
        self, source: "ToolUsage", event: "ToolUsageFinishedEvent"
    ) -> None:  # pylint: disable=unused-argument
        attrs: Dict[str, Any] = {}
        output = getattr(event, "output", None)
        if output is not None:
            attrs[GEN_AI_TOOL_CALL_RESULT] = to_tool_attribute_value(output)
        self._end_span(event.started_event_id, attrs)

    def _on_tool_error(
        self, source: "ToolUsage", event: "ToolUsageErrorEvent"
    ) -> None:  # pylint: disable=unused-argument
        self._end_span(event.started_event_id, error=str(event.error))

    def _on_llm_start(self, source: "BaseLLM", event: "LLMCallStartedEvent") -> None:
        attributes: Dict[str, Any] = {
            GEN_AI_OPERATION_NAME: GenAiOperationNameValues.CHAT.value,
        }

        provider, model_name = self._extract_provider_and_model(source)
        if provider:
            attributes[GEN_AI_PROVIDER_NAME] = provider
        if model_name:
            attributes[GEN_AI_REQUEST_MODEL] = model_name
        self._set_llm_request_span_attributes(attributes, source, event)

        span_name = (
            f"{GenAiOperationNameValues.CHAT.value} {model_name}" if model_name else GenAiOperationNameValues.CHAT.value
        )

        usage = source.get_token_usage_summary()

        messages = event.messages
        if messages:
            if isinstance(messages, str):
                messages = [{"role": "user", "content": messages}]
            system_instructions = [m for m in messages if m.get("role") == "system"]
            non_system_messages = [m for m in messages if m.get("role") != "system"]
            if system_instructions:
                parts = [p for m in system_instructions for p in content_to_parts(m.get("content", ""))]
                attributes[GEN_AI_SYSTEM_INSTRUCTIONS] = serialize_to_json_string(parts)
            if non_system_messages:
                attributes[GEN_AI_INPUT_MESSAGES] = serialize_to_json_string(
                    [self._to_input_message(m) for m in non_system_messages]
                )

        parent_event_id = self._get_parent_event_id(event)
        self._start_span(
            span_name,
            event.event_id,
            attributes,
            parent_event_id,
            kind=SpanKind.CLIENT,
            initial_token_usage=(usage.prompt_tokens, usage.completion_tokens),
        )
        self._task_or_agent_id_to_started_llm_event_id.put(self._get_task_or_agent_id(event), event.event_id)

    def _on_llm_completed(  # pylint: disable=too-many-locals,too-many-branches
        self, source: "BaseLLM", event: "LLMCallCompletedEvent"
    ) -> None:
        attrs: Dict[str, Any] = {}

        from crewai.events.types.llm_events import LLMCallType  # pylint: disable=import-outside-toplevel

        finish_reason = getattr(event, "finish_reason", None) or (
            "tool_call" if event.call_type == LLMCallType.TOOL_CALL else "stop"
        )
        attrs[GEN_AI_RESPONSE_FINISH_REASONS] = [finish_reason]
        if response_id := getattr(event, "response_id", None):
            attrs[GEN_AI_RESPONSE_ID] = response_id

        response = event.response
        if response:
            if isinstance(response, str):
                attrs[GEN_AI_OUTPUT_MESSAGES] = serialize_to_json_string(
                    [self._to_output_message({"role": "assistant", "content": response}, finish_reason)]
                )
            elif isinstance(response, list) and response:
                if isinstance(response[0], dict) and "role" in response[0]:
                    attrs[GEN_AI_OUTPUT_MESSAGES] = serialize_to_json_string(
                        [self._to_output_message(m, finish_reason) for m in response]
                    )
                else:
                    parts = self._to_tool_call_parts(response)
                    if parts:
                        attrs[GEN_AI_OUTPUT_MESSAGES] = serialize_to_json_string(
                            [{"role": "assistant", "parts": parts, "finish_reason": finish_reason}]
                        )

        _, model_name = self._extract_provider_and_model(source)
        if model_name:
            attrs[GEN_AI_RESPONSE_MODEL] = model_name

        started_event_id = first_not_none(
            self._task_or_agent_id_to_started_llm_event_id.pop(self._get_task_or_agent_id(event)),
            event.started_event_id,
        )

        # crewai >=1.13.0 reports per-call usage on the completed event; older versions only expose a
        # cumulative summary, so diff it against the snapshot taken when the call started.
        span_entry = self._event_id_to_span.get(started_event_id)
        prev_prompt_tokens, prev_completion_tokens = span_entry.initial_token_usage if span_entry else (0, 0)
        event_usage = getattr(event, "usage", None)
        cache_read_input_tokens = 0
        cache_creation_input_tokens = 0
        reasoning_output_tokens = 0
        if isinstance(event_usage, dict):
            input_tokens = (
                event_usage.get("prompt_tokens")
                or event_usage.get("inputTokens")
                or event_usage.get("input_tokens")
                or 0
            )
            output_tokens = (
                event_usage.get("completion_tokens")
                or event_usage.get("outputTokens")
                or event_usage.get("output_tokens")
                or 0
            )
            cache_read_input_tokens = event_usage.get("cached_prompt_tokens") or 0
            cache_creation_input_tokens = event_usage.get("cache_creation_tokens") or 0
            reasoning_output_tokens = event_usage.get("reasoning_tokens") or 0
        else:
            usage: "UsageMetrics" = source.get_token_usage_summary()
            input_tokens = usage.prompt_tokens - prev_prompt_tokens
            output_tokens = usage.completion_tokens - prev_completion_tokens
        if input_tokens > 0:
            attrs[GEN_AI_USAGE_INPUT_TOKENS] = input_tokens
        if output_tokens > 0:
            attrs[GEN_AI_USAGE_OUTPUT_TOKENS] = output_tokens
        if cache_read_input_tokens > 0:
            attrs[GEN_AI_USAGE_CACHE_READ_INPUT_TOKENS] = cache_read_input_tokens
        if cache_creation_input_tokens > 0:
            attrs[GEN_AI_USAGE_CACHE_CREATION_INPUT_TOKENS] = cache_creation_input_tokens
        if reasoning_output_tokens > 0:
            attrs[GEN_AI_USAGE_REASONING_OUTPUT_TOKENS] = reasoning_output_tokens

        self._end_span(started_event_id, attrs)

    def _on_llm_failed(self, source: Any, event: "LLMCallFailedEvent") -> None:
        started_event_id = first_not_none(
            self._task_or_agent_id_to_started_llm_event_id.pop(self._get_task_or_agent_id(event)),
            event.started_event_id,
        )
        self._end_span(started_event_id, error=getattr(event, "error", None))

    def _maybe_end_pending_llm_span_for_tool_call(self, source: Any, event: "ToolUsageStartedEvent") -> None:
        # Some CrewAI tool-call paths transition directly to ToolUsageStartedEvent
        # without a matching LLMCallCompletedEvent. Finalize the pending LLM span
        # with the tool call and token usage before the tool span starts.
        agent = first_not_none(getattr(source, "agent", None), self._get_event_agent(event))
        llm = source if hasattr(source, "get_token_usage_summary") else getattr(agent, "llm", None)
        if not llm:
            return
        started_event_id = self._task_or_agent_id_to_started_llm_event_id.pop(self._get_task_or_agent_id(event))
        if not started_event_id:
            return

        parts = []
        for message in reversed(getattr(source, "messages", None) or []):
            if isinstance(message, dict) and message.get("role") == "assistant":
                parts = self._to_tool_call_parts(message.get("tool_calls") or [])
                if parts:
                    break
        if not parts:
            parts = self._to_tool_call_parts([{"name": event.tool_name, "input": event.tool_args}])

        attrs: Dict[str, Any] = {
            GEN_AI_RESPONSE_FINISH_REASONS: ["tool_call"],
            GEN_AI_OUTPUT_MESSAGES: serialize_to_json_string(
                [{"role": "assistant", "parts": parts, "finish_reason": "tool_call"}]
            ),
        }
        _, model_name = self._extract_provider_and_model(llm)
        if model_name:
            attrs[GEN_AI_RESPONSE_MODEL] = model_name

        span_entry = self._event_id_to_span.get(started_event_id)
        previous = span_entry.initial_token_usage if span_entry else (0, 0)
        usage: "UsageMetrics" = llm.get_token_usage_summary()
        if (input_tokens := usage.prompt_tokens - previous[0]) > 0:
            attrs[GEN_AI_USAGE_INPUT_TOKENS] = input_tokens
        if (output_tokens := usage.completion_tokens - previous[1]) > 0:
            attrs[GEN_AI_USAGE_OUTPUT_TOKENS] = output_tokens

        self._end_span(started_event_id, attrs)

    def _get_parent_event_id(self, event: Any) -> Optional[str]:
        parent_event_id = getattr(event, "parent_event_id", None)
        if parent_event_id and self._event_id_to_span.get(parent_event_id):
            return parent_event_id
        task_or_agent_id = self._get_task_or_agent_id(event)
        return (
            task_or_agent_id if task_or_agent_id and self._event_id_to_span.get(task_or_agent_id) else parent_event_id
        )

    @staticmethod
    def _get_task_or_agent_id(event: Any) -> str:
        task_id = first_not_none(
            getattr(getattr(event, "task", None), "id", None),
            getattr(event, "task_id", None),
        )
        agent_id = first_not_none(
            getattr(getattr(event, "agent", None), "id", None),
            getattr(event, "agent_id", None),
        )
        return str(first_not_none(task_id, agent_id, ""))

    @staticmethod
    def _get_event_agent(event: Any) -> Any:
        return first_not_none(
            getattr(event, "from_agent", None),
            getattr(event, "agent", None),
            getattr(event, "agent_id", None),
        )

    def _start_span(
        self,
        name: str,
        event_id: str,
        attributes: Optional[Dict[str, Any]] = None,
        parent_event_id: Optional[str] = None,
        kind: SpanKind = SpanKind.INTERNAL,
        *,
        root_event_id: Optional[str] = None,
        initial_token_usage: Tuple[int, int] = (0, 0),
    ) -> None:
        parent_entry = self._event_id_to_span.get(parent_event_id) if parent_event_id else None
        if parent_entry:
            # continue the trace under the parent span recorded for this CrewAI event
            parent_ctx = trace.set_span_in_context(parent_entry.span)
        elif root_event_id is not None or parent_event_id is None:
            # a CrewAI root may run inside an incoming request trace, preserving that
            # caller context when CrewAI does not provide a parent span to continue
            parent_ctx = context.get_current()
        else:
            # the parent ID is missing from our span map, so do not
            # use the active context because it may belong to another concurrent crew
            parent_ctx = context.Context()

        if root_event_id is None:
            if parent_entry:
                root_event_id = parent_entry.root_event_id
            else:
                # If the parent has already been cleaned up, keep this orphan in its own cleanup scope.
                root_event_id = event_id
        span = self._tracer.start_span(name, kind=kind, attributes=attributes, context=parent_ctx)
        token = context.attach(trace.set_span_in_context(span))
        self._event_id_to_span.put(
            event_id,
            _SpanEntry(
                span=span,
                token=token,
                root_event_id=root_event_id,
                initial_token_usage=initial_token_usage,
            ),
        )

    def _end_span(
        self,
        started_event_id: Optional[str],
        set_attrs: Optional[Dict[str, Any]] = None,
        error: Optional[str] = None,
    ) -> None:
        if not started_event_id:
            return
        entry = self._event_id_to_span.pop(started_event_id)
        if entry:
            if set_attrs:
                for key, value in set_attrs.items():
                    if value is not None:
                        entry.span.set_attribute(key, value)
            if error:
                entry.span.set_status(Status(StatusCode.ERROR, error))
                entry.span.set_attribute(ERROR_TYPE, error)
            else:
                entry.span.set_status(Status(StatusCode.OK))
            entry.span.end()
            try_detach(entry.token)

    def _end_spans_for_root_event(self, root_event_id: Optional[str], error: Optional[str] = None) -> None:
        if not root_event_id:
            return

        removed_span_entries = self._event_id_to_span.pop_items_if_matches(
            lambda _, span_entry: span_entry.root_event_id == root_event_id
        )
        removed_event_ids = {event_id for event_id, _entry in removed_span_entries}
        self._task_or_agent_id_to_started_llm_event_id.pop_items_if_matches(
            lambda _, event_id: event_id in removed_event_ids
        )
        for _, entry in reversed(removed_span_entries):
            if entry.span.is_recording():
                if error:
                    entry.span.set_status(Status(StatusCode.ERROR, error))
                    entry.span.set_attribute(ERROR_TYPE, error)
                else:
                    entry.span.set_status(Status(StatusCode.OK))
                entry.span.end()
                try_detach(entry.token)

    @staticmethod
    def _extract_provider_and_model(llm: Any) -> Tuple[Optional[str], Optional[str]]:
        if not llm:
            return None, None
        model = getattr(llm, "model", None)
        if not model:
            return None, None
        if "/" in model:
            prefix, _, model_part = model.partition("/")
            provider_name = PROVIDER_MAP.get(prefix.lower(), prefix)
            return provider_name, model_part
        provider = getattr(llm, "provider", None)
        if provider:
            return PROVIDER_MAP.get(provider.lower(), provider), model
        return None, model

    @staticmethod
    def _to_input_message(msg: Dict[str, Any]) -> Dict[str, Any]:
        role = msg.get("role", "user")
        if role == "tool":
            part: Dict[str, Any] = {"type": "tool_call_response"}
            if msg.get("tool_call_id"):
                part["id"] = msg["tool_call_id"]
            part["response"] = msg.get("content", "")
            return {"role": role, "parts": [part]}
        parts = []
        content = msg.get("content")
        if content:
            parts.extend(content_to_parts(content))
        tool_calls = msg.get("tool_calls")
        if tool_calls:
            parts.extend(OpenTelemetryEventHandler._to_tool_call_parts(tool_calls))
        if not parts:
            parts.append({"type": "text", "content": ""})
        return {"role": role, "parts": parts}

    @staticmethod
    def _to_output_message(msg: Dict[str, Any], finish_reason: str = "stop") -> Dict[str, Any]:
        parts = []
        content = msg.get("content")
        if content:
            parts.extend(content_to_parts(content))
        tool_calls = msg.get("tool_calls")
        if tool_calls:
            parts.extend(OpenTelemetryEventHandler._to_tool_call_parts(tool_calls))
        if not parts:
            parts.append({"type": "text", "content": ""})
        return {
            "role": msg.get("role", "assistant"),
            "parts": parts,
            "finish_reason": finish_reason,
        }

    @staticmethod
    def _set_llm_request_span_attributes(
        attributes: Dict[str, Any],
        llm: "BaseLLM",
        event: Optional["LLMCallStartedEvent"] = None,
    ) -> None:
        additional_params = getattr(llm, "additional_params", None) or {}
        additional_model_request_fields = getattr(llm, "additional_model_request_fields", None) or {}
        stop = first_not_none(
            getattr(event, "stop_sequences", None),
            getattr(event, "stop", None),
            getattr(llm, "stop_sequences", None),
            getattr(llm, "stop", None),
            additional_params.get("stop_sequences"),
            additional_params.get("stop"),
            additional_model_request_fields.get("stop_sequences"),
            additional_model_request_fields.get("stop"),
        )
        request_attributes = {
            GEN_AI_REQUEST_TEMPERATURE: first_not_none(
                getattr(event, "temperature", None),
                getattr(llm, "temperature", None),
                additional_params.get("temperature"),
                additional_model_request_fields.get("temperature"),
            ),
            GEN_AI_REQUEST_TOP_P: first_not_none(
                getattr(event, "top_p", None),
                getattr(llm, "top_p", None),
                additional_params.get("top_p"),
                additional_model_request_fields.get("top_p"),
            ),
            GEN_AI_REQUEST_TOP_K: first_not_none(
                getattr(event, "top_k", None),
                getattr(llm, "top_k", None),
                additional_params.get("top_k"),
                additional_model_request_fields.get("top_k"),
            ),
            GEN_AI_REQUEST_MAX_TOKENS: first_not_none(
                getattr(event, "max_tokens", None),
                getattr(event, "max_output_tokens", None),
                getattr(event, "max_completion_tokens", None),
                getattr(llm, "max_tokens", None),
                getattr(llm, "max_output_tokens", None),
                getattr(llm, "max_completion_tokens", None),
                additional_params.get("max_tokens"),
                additional_params.get("max_output_tokens"),
                additional_params.get("max_completion_tokens"),
                additional_model_request_fields.get("max_tokens"),
                additional_model_request_fields.get("max_output_tokens"),
                additional_model_request_fields.get("max_completion_tokens"),
            ),
            GEN_AI_REQUEST_FREQUENCY_PENALTY: first_not_none(
                getattr(event, "frequency_penalty", None),
                getattr(llm, "frequency_penalty", None),
                additional_params.get("frequency_penalty"),
                additional_model_request_fields.get("frequency_penalty"),
            ),
            GEN_AI_REQUEST_PRESENCE_PENALTY: first_not_none(
                getattr(event, "presence_penalty", None),
                getattr(llm, "presence_penalty", None),
                additional_params.get("presence_penalty"),
                additional_model_request_fields.get("presence_penalty"),
            ),
            GEN_AI_REQUEST_SEED: first_not_none(
                getattr(event, "seed", None),
                getattr(llm, "seed", None),
                additional_params.get("seed"),
                additional_model_request_fields.get("seed"),
            ),
            GEN_AI_REQUEST_CHOICE_COUNT: first_not_none(
                getattr(event, "choice_count", None),
                getattr(event, "n", None),
                getattr(llm, "choice_count", None),
                getattr(llm, "n", None),
                additional_params.get("choice_count"),
                additional_params.get("n"),
                additional_model_request_fields.get("choice_count"),
                additional_model_request_fields.get("n"),
            ),
            GEN_AI_REQUEST_STREAM: first_not_none(
                getattr(event, "stream", None),
                getattr(llm, "stream", None),
                additional_params.get("stream"),
                additional_model_request_fields.get("stream"),
            ),
            GEN_AI_REQUEST_STOP_SEQUENCES: ([stop] if isinstance(stop, str) else stop) or None,
        }
        attributes.update({attribute: value for attribute, value in request_attributes.items() if value is not None})

    @staticmethod
    def _to_tool_call_parts(tool_calls: list) -> list:
        parts = []
        for tc in tool_calls:
            part: Dict[str, Any] = {"type": "tool_call"}
            if isinstance(tc, dict):
                function = tc.get("function") or {}
                if name := tc.get("name") or function.get("name"):
                    part["name"] = name
                if arguments := tc.get("input") or tc.get("arguments") or function.get("arguments"):
                    part["arguments"] = arguments
                tc_id = tc.get("toolUseId") or tc.get("id")
                if tc_id:
                    part["id"] = tc_id
            elif hasattr(tc, "function"):
                func = tc.function
                if getattr(func, "name", None):
                    part["name"] = func.name
                if getattr(func, "arguments", None):
                    part["arguments"] = func.arguments
                if getattr(tc, "id", None):
                    part["id"] = tc.id
            else:
                continue
            parts.append(part)
        return parts

    @staticmethod
    def _find_tool_description(source: Any, event: Any, tool_name: Optional[str]) -> Optional[str]:
        if not tool_name:
            return None
        tool_class = getattr(event, "tool_class", None)
        if tool_class:
            desc = getattr(tool_class, "description", None)
            if desc:
                return OpenTelemetryEventHandler._normalize_tool_description(desc)
        for tools_holder in [source, getattr(source, "agent", None), getattr(event, "agent", None)]:
            tools = getattr(tools_holder, "tools", None) if tools_holder else None
            if not tools:
                continue
            for tool in tools:
                if getattr(tool, "name", None) == tool_name:
                    desc = getattr(tool, "description", None)
                    if desc:
                        return OpenTelemetryEventHandler._normalize_tool_description(desc)
        return None

    @staticmethod
    def _extract_tool_definitions(tools: Any) -> list:
        defs = []
        for tool in tools:
            tool_def: Dict[str, Any] = {"type": "function"}
            if name := getattr(tool, "name", None):
                tool_def["name"] = name
            if desc := OpenTelemetryEventHandler._normalize_tool_description(getattr(tool, "description", None)):
                tool_def["description"] = desc
            args_schema = getattr(tool, "args_schema", None)
            if args_schema is not None:
                try:
                    tool_def["parameters"] = args_schema.model_json_schema()
                except Exception:  # pylint: disable=broad-exception-caught
                    pass
            defs.append(tool_def)
        return defs

    @staticmethod
    def _normalize_tool_description(desc: Optional[str]) -> Optional[str]:
        # crewai <1.15.3 stored the LLM prompt composite in description; strip it to the authored text.
        # See crewai 1.15.3 changelog: https://github.com/crewAIInc/crewAI/releases/tag/1.15.3
        if not desc:
            return desc
        match = re.match(r"^Tool Name:.*\nTool Arguments:.*\nTool Description:\s*", desc, re.DOTALL)
        return desc[match.end() :] if match else desc
